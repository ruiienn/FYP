package fyp.tayxinyu;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class WalletController {
	@GetMapping("/wallet")
	public String wallet() {
		return "wallet";
	}
	@GetMapping("/history")
	public String history() {
		return "history";
	}
	@GetMapping("/redeem")
	public String redeem() {
		return "redeem";
	}

}
